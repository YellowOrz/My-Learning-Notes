Process steps and Information:

1- Install Internet Download Manager.

2- *Important: Please opy the patcher to the IDM installation directory and run it there; otherwise, patching
cannot be done.

  *Note: "When you press the Patcher's Patch button, "IDM Fake Serial Reg-entries Cleaner & Register Script"
will run automatically at the start of the patch process, so the next Patcher interface will start with
a delay of a few seconds, > so, please wait a few seconds and do not hurry.

  Perform patching operations when second-party applications are launched. The update disabler application
disables IDM's update function; if you do not want to disable IDM's update function, you can press to
IDM Update Disabler app's Exit button when opened IDM Update Disabler app's interface."

- Enjoy! :)


























