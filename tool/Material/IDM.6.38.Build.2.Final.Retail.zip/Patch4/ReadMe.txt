
First of all, I recommend you to install a clean IDM.
If exist nlaapi.dll and version.dll files in Internet
Download Manager's install directory, please delete them;
otherwise, IDMan will not be launch.
******************
1- Install Internet Download Manager

2- Apply Patch & Fake Serial issues will be fixed,
please wait a moment while the issues are fixed and
the registration process is in progress !

3- Enjoy ! :)
******************
Note: Both patches are prepared for an IDM that will
be cracked & registered.

*IDMan v6.37.15 Patcher : Applies a normal patching to IDM
*IDMan v6.37.15 Patcher (no update) : Applies a patching to
IDM by disabling IDM's update.
******************




